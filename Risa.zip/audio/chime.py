import pygame
import time
from config import CHIME_FILE

def play_ding():
    pygame.mixer.init()
    pygame.mixer.music.load(CHIME_FILE)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.05)
    pygame.mixer.music.unload()
    pygame.mixer.quit()
