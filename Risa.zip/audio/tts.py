import asyncio
import os
import tempfile
import time
import edge_tts
import pygame


def speak(text):
    # 1. Define the async function to communicate with Edge TTS
    async def generate_speech():
        # You can change the voice here (e.g., "en-US-AvaMultilingualNeural")
        voice = "en-US-ChristopherNeural"
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(temp_path)

    # 2. Set up the temporary file context
    with tempfile.TemporaryDirectory() as tmpdirname:
        temp_path = os.path.join(tmpdirname, "speech.mp3")

        # 3. Run the async audio generation
        asyncio.run(generate_speech())

        # 4. Play the audio using your existing Pygame logic
        pygame.mixer.init()
        pygame.mixer.music.load(temp_path)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            time.sleep(0.1)

        pygame.mixer.music.unload()
        pygame.mixer.quit()


# Example Usage:
if __name__ == "__main__":
    speak("Hello! I am now speaking using Microsoft Edge's natural text to speech engine.")