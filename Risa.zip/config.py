# Model details
VOSK_MODEL_FOLDER = 'vosk-model-small-en-us-0.15'
VOSK_MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
VOSK_MODEL_ZIP = "voicemodel.zip"

# Sound files
CHIME_FILE = "chime.mp3"

# AI API
AI_URL = "http://localhost:11434/api/generate"
AI_MODEL = "deepseek-r1:1.5b"

WAKE_WORDS = ["hey risa", "hey lisa", "risa", "lisa"]
TTS_MODEL = "tts_models/en/ljspeech/vits"