import json
from audio.audio_queue import q

def listen_for_command(rec):
    while True:
        data = q.get()
        if rec.AcceptWaveform(data):
            result_json = json.loads(rec.Result())
            result = result_json.get("text", "").lower().strip()
            if result:
                return result
