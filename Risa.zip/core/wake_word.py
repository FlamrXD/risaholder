from .speech_recognition import listen_for_command
from config import WAKE_WORDS

def detect_wake_word(rec):
    phrase = listen_for_command(rec)
    return any(phrase.startswith(word) for word in WAKE_WORDS)
