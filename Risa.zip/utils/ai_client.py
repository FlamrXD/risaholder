import re
import ollama
from audio.tts import speak

AI_MODEL = "gemma3:1b"
AI_HOST = "http://localhost:11434"

def clean_response(text):
    """Removes thinking process tags and strips extra whitespace."""
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    lines = [line for line in cleaned.splitlines() if line.strip()]
    return "\n".join(lines).strip()

def check_and_install_model(client):
    """Checks if the model is installed. If not, prompts the user to download it."""
    try:
        # Check if model is already present locally
        local_models = client.list()
        models_list = [m.get('model') for m in local_models.get('models', [])]
        
        # Ollama sometimes appends ':latest' or handles tags subtly; check for exact or base match
        if AI_MODEL in models_list or f"{AI_MODEL}:latest" in models_list:
            return True

    except Exception:
        # If we can't even list models, the Ollama service might be down entirely
        print(f"\n[Error] Cannot connect to Ollama server at {AI_HOST}. Is it running?")
        return False

    # Model was not found, enter user prompt loop
    print(f"\n[Notice] The model '{AI_MODEL}' is not installed.")
    speak(f"The required AI model, {AI_MODEL}, is not installed. Would you like to install it now?")
    
    while True:
        user_input = input("Install model? (Yes / No / How does it work?): ").strip().lower()
        
        # Handle "Yes" variations
        if user_input in ["yes", "y", "sure", "yeah", "ok"]:
            print(f"Pulling '{AI_MODEL}' from Ollama registry. Please wait...")
            speak("Downloading the model now. This may take a moment depending on your internet connection.")
            try:
                # Streaming the download progress bars
                current_digest = None
                for progress in client.pull(model=AI_MODEL, stream=True):
                    status = progress.get('status', '')
                    digest = progress.get('digest', '')
                    total = progress.get('total', 0)
                    completed = progress.get('completed', 0)
                    
                    if digest and digest != current_digest:
                        print(f"\nDownloading layer {digest[:12]}...")
                        current_digest = digest
                    
                    if total > 0:
                        percentage = int((completed / total) * 100)
                        print(f"\rStatus: {status} | {percentage}%", end="", flush=True)
                    else:
                        print(f"\rStatus: {status}", end="", flush=True)
                
                print("\nDownload complete!")
                speak("The model has been successfully installed.")
                return True
            except Exception as e:
                print(f"\nFailed to download model: {e}")
                speak("Sorry, the download encountered an error.")
                return False
                
        # Handle "No" variations
        elif user_input in ["no", "n", "nope", "cancel"]:
            print("Installation cancelled by user.")
            speak("Okay, cancelling installation. I won't be able to process your question without the model.")
            return False
            
        # Handle "How does it work" variations
        elif "how" in user_input or "work" in user_input or "what" in user_input:
            explanation = (
                f"Ollama runs models locally on your machine. Because '{AI_MODEL}' isn't on your "
                "computer yet, I need to download its weights from the official Ollama registry. "
                "Once downloaded, it runs completely offline."
            )
            print(f"\n{explanation}\n")
            speak(explanation)
            speak("Would you like to proceed with the installation now?")
            # The loop continues to ask them for a Yes or No
            
        else:
            print("I didn't quite catch that.")
            speak("Please say yes, no, or ask how it works.")

def ask_ai(prompt):
    try:
        client = ollama.Client(host=AI_HOST)
        
        # Run the installation check guard first
        if not check_and_install_model(client):
            return

        full_prompt = (
            "You must answer in exactly one or two sentences.\n\n"
            f"Question: {prompt}\n"
            "Answer:"
        )

        print("Thinking...", end="", flush=True)
        
        stream = client.generate(
            model=AI_MODEL,
            prompt=full_prompt,
            stream=True
        )

        ai_text = ""
        for chunk in stream:
            text_piece = chunk.get("response", "")
            if text_piece:
                print(text_piece, end="", flush=True)
                ai_text += text_piece

        print()
        
        final_text = clean_response(ai_text)
        
        if not final_text:
            speak("Sorry, I got no response from the AI.")
        else:
            speak(final_text)

    except Exception as e:
        print("\nAI Error:", e)
        speak("Sorry, I couldn't connect to the AI.")