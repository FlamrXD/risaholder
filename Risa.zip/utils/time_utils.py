from datetime import datetime

def time_to_words(dt: datetime):
    hour = dt.hour % 12 or 12
    minute = dt.minute
    numbers = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
               "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
               "eighteen", "nineteen", "twenty", "twenty-one", "twenty-two", "twenty-three",
               "twenty-four", "twenty-five", "twenty-six", "twenty-seven", "twenty-eight",
               "twenty-nine", "thirty", "thirty-one", "thirty-two", "thirty-three", "thirty-four",
               "thirty-five", "thirty-six", "thirty-seven", "thirty-eight", "thirty-nine",
               "forty", "forty-one", "forty-two", "forty-three", "forty-four", "forty-five",
               "forty-six", "forty-seven", "forty-eight", "forty-nine", "fifty", "fifty-one",
               "fifty-two", "fifty-three", "fifty-four", "fifty-five", "fifty-six", "fifty-seven",
               "fifty-eight", "fifty-nine"]
    am_pm = "AM" if dt.hour < 12 else "PM"
    if minute == 0:
        return f"{numbers[hour]} o'clock {am_pm}"
    elif minute < 10:
        return f"{numbers[hour]} oh {numbers[minute]} {am_pm}"
    else:
        return f"{numbers[hour]} {numbers[minute]} {am_pm}"
