import os
import requests
import zipfile
from config import VOSK_MODEL_FOLDER, VOSK_MODEL_URL, VOSK_MODEL_ZIP
import vosk

def setup_vosk_model():
    if not os.path.isdir(VOSK_MODEL_FOLDER):
        print("Downloading Vosk model")
        response = requests.get(VOSK_MODEL_URL)
        with open(VOSK_MODEL_ZIP, "wb") as file:
            file.write(response.content)
        with zipfile.ZipFile(VOSK_MODEL_ZIP, 'r') as zip_ref:
            zip_ref.extractall()
        print("Downloaded!")

    model = vosk.Model(VOSK_MODEL_FOLDER)
    rec = vosk.KaldiRecognizer(model, 16000)
    return rec
