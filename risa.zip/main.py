import os
import subprocess
import webbrowser
from datetime import datetime, date
import speech_recognition as sr
import pyautogui
import time

from audio.chime import play_ding
from utils.time_utils import time_to_words
from audio.tts import speak
from utils.ai_client import ask_ai

recognizer = sr.Recognizer()
microphone = sr.Microphone()

recognizer.dynamic_energy_threshold = False
recognizer.energy_threshold = 300  
recognizer.pause_threshold = 1

def process_command(command: str) -> bool:
    command = command.lower().strip()
    if not command:
        return False

    print(f"Executing command: '{command}'")

    # TIME
    if any(word in command for word in ["time", "what time", "current time"]):
        now = datetime.now()
        time_words = time_to_words(now)
        speak(f"The time is {time_words}")
        return True

    elif any(word in command for word in ["date", "today", "what's the date"]):
        today_date = date.today().strftime("%B %d, %Y")
        speak(f"The date is {today_date}")
        return True

    #  who are you, i am steve (identity) 
    elif any(phrase in command for phrase in ["who are you", "your name", "what do you do"]):
        speak("Hi, my name is Risa. I'm your voice assistant.")
        return True

    #  MEDIA  
    elif any(phrase in command for phrase in ["pause", "pause music", "pause video", "play", "resume"]):
        pyautogui.press('playpause')
        speak("Done")
        return True

    elif "volume up" in command:
        for _ in range(5): pyautogui.press("volumeup")
        speak("Volume up")
        return True

    elif "volume down" in command:
        for _ in range(5): pyautogui.press("volumedown")
        speak("Volume down")
        return True

    elif "mute" in command:
        pyautogui.press("volumemute")
        return True

    #  WEB & OS CONTROLS 
    elif "open google" in command:
        speak("Opening Google")
        webbrowser.open("https://google.com")
        return True

    elif "open youtube" in command:
        speak("Opening Youtube")
        webbrowser.open("https://youtube.com")
        return True

    elif "search for" in command:
        query = command.split("search for")[-1].strip()
        if query:
            speak(f"Searching for {query}")
            webbrowser.open(f"https://www.google.com/search?q={query}")
        return True

    elif "open calculator" in command:
        speak("Opening Calculator")
        if os.name == 'nt':
            subprocess.Popen('calc.exe')
        else:
            subprocess.Popen('gnome-calculator' if os.name == 'posix' else 'open -a Calculator')
        return True

    elif any(phrase in command for phrase in ["stop listening", "exit", "shutdown"]):
        speak("Shutting down. Goodbye!")
        os._exit(0)

    #  AI INTEGRATION
    prompt = command
    if prompt.startswith("ask ai") or prompt.startswith("ask a i"):
        for phrase in ["ask ai", "ask a i"]:
            if prompt.startswith(phrase):
                prompt = prompt.replace(phrase, "", 1).strip(" :")
                break

    if prompt:
        speak("Asking AI...")
        ask_ai(prompt)
        return True
    else:
        speak("What would you like to ask?")
        return True

def main():
    with microphone as source:
        print("Calibrating background noise...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
    
    print("\nRisa is active... Say 'Hey Risa [your command]' in one sentence!")

    in_conversation = False

    with microphone as source:
        while True:
            try:
                if not in_conversation:
                    print(".", end="", flush=True) # Idle heartbeat
                    audio = recognizer.listen(source, timeout=None, phrase_time_limit=10)
                    raw_text = recognizer.recognize_google(audio).lower()
                    
                    if "hey risa" in raw_text or "hey lisa" in raw_text:
                        print(f"\n[Triggered]: '{raw_text}'")
                        
                        command_text = raw_text.split("risa")[-1].split("lisa")[-1].strip()
                        
                        if command_text:
                            executed = process_command(command_text)
                            if executed:
                                in_conversation = True  
                        else:
                            play_ding()
                            speak("How can I help?")
                            in_conversation = True

                else:
                    print("\n[Follow-up Mode: Listening for next command...]")
                    # Shorter timeout: if you don't say anything in 4 seconds, conversation ends
                    audio = recognizer.listen(source, timeout=4, phrase_time_limit=5)
                    command_text = recognizer.recognize_google(audio).lower()
                    print(f"[Follow-up Heard]: '{command_text}'")
                    
                    # Direct execution without checking for the wake word
                    executed = process_command(command_text)
                    if not executed:
                        in_conversation = False
                        print("\nReturning to idle mode...")

            except sr.UnknownValueError:
                if in_conversation:
                    print("\nConversation timed out due to unclear audio. Going to sleep.")
                    in_conversation = False
            except (sr.WaitTimeoutError, sr.RequestError):
                if in_conversation:
                    print("\nNo follow-up detected. Going to sleep.")
                    in_conversation = False
            except Exception as e:
                print(f"\nUnexpected error: {e}")
                in_conversation = False

if __name__ == "__main__":
    main()