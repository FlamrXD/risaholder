from PySide6.QtWidgets import (
    QApplication, QWidget, QLabel, QVBoxLayout, QProgressBar
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

class CustomPanel(QWidget):
    def __init__(self):
        super().__init__()

        # Make the window frameless and translucent background for demo (optional)


        # Layout container
        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(10)

        # Title label (bold and big)
        self.title = QLabel("risa")
        self.title.setFont(QFont("Arial", 24, QFont.Bold))
        self.title.setStyleSheet("color: white;")
        self.title.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title)

        # Subtitle label (smaller, lighter)
        self.subtitle = QLabel("what is the time")
        self.subtitle.setFont(QFont("Arial", 12))
        self.subtitle.setStyleSheet("color: white;")
        self.subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.subtitle)

        # Info label (medium size, bold)
        self.info = QLabel("The Time is\n10:40 PM")
        self.info.setFont(QFont("Arial", 18, QFont.Bold))
        self.info.setStyleSheet("color: white;")
        self.info.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.info)

        # Progress bar (green, styled)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(60)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(20)
        layout.addWidget(self.progress)

        self.setLayout(layout)
        self.resize(400, 200)

    def paintEvent(self, event):
        # Draw semi-transparent rounded rect background
        from PySide6.QtGui import QPainter, QColor, QBrush
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect()

        bg_color = QColor(255, 255, 255, 60)  # white with alpha ~ 60
        painter.setBrush(QBrush(bg_color))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(rect, 20, 20)


if __name__ == "__main__":
    app = QApplication([])
    window = CustomPanel()
    window.show()
    app.exec()
