import re
import ollama
from audio.tts import speak

# Hardcoded configurations to eliminate config.py
AI_MODEL = "gemma3:1b"
AI_HOST = "http://localhost:11434"

def clean_response(text):
    """Removes thinking process tags and strips extra whitespace."""
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    lines = [line for line in cleaned.splitlines() if line.strip()]
    return "\n".join(lines).strip()

def ask_ai(prompt):
    try:
        full_prompt = (
            "You must answer in exactly one or two sentences.\n\n"
            f"Question: {prompt}\n"
            "Answer:"
        )

        print("Thinking...", end="", flush=True)
        
        # Explicitly pointing the Client to your local port and model
        client = ollama.Client(host=AI_HOST)
        stream = client.generate(
            model=AI_MODEL,
            prompt=full_prompt,
            stream=True
        )

        ai_text = ""
        for chunk in stream:
            text_piece = chunk.get("response", "")
            if text_piece:
                print(text_piece, end="", flush=True)
                ai_text += text_piece

        print() # Line break after text finishes streaming
        
        # Clean the response text
        final_text = clean_response(ai_text)
        
        if not final_text:
            speak("Sorry, I got no response from the AI.")
        else:
            speak(final_text)

    except Exception as e:
        print("\nAI Error:", e)
        speak("Sorry, I couldn't connect to the AI.")